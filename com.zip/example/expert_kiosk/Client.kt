package com.example.expert_kiosk

class Client(val clNumber:Int, val clGrade:Int)