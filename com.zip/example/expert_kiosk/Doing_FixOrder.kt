package com.example.expert_kiosk

class MenuTable {




}