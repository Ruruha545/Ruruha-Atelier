package com.example.expert_kiosk

interface ExtensionFunc {
    // 키오스크 동작루프_1 內 사용 가능한 "처음으로 돌아가기" 기능
    fun Taecho(sigFunc:String?):Int{
        var sigLoop:Int
        if(sigFunc == null){ println("기능을 선택하지 않았습니다. 처음으로 돌아갑니다."); return 10 }
        else{
            try{ sigLoop = sigFunc.toInt(); return sigLoop }
            catch(e: NumberFormatException){
                println("입력이 잘못되었습니다. 처음으로 돌아갑니다."); return 10 }
        }
    }
}


// 키오스크 동작루프_1 內 사용 가능한 "처음으로 돌아가기" 기능
//fun Taecho(sigFunc:String?):Int{
//    var sigLoop:Int
//    if(sigFunc == null){ println("기능을 선택하지 않았습니다. 처음으로 돌아갑니다."); return 10 }
//    else{
//        try{ sigLoop = sigFunc.toInt() }
//        catch(e: NumberFormatException){
//            println("입력이 잘못되었습니다. 처음으로 돌아갑니다."); return sigLoop }
//    }
//}

//// 변수 치환(funcTop >> retry) 간 에러발생에 따른 예외처리 적용
//if(funcTop == null){
//    println("기능이 입력되지 않았습니다. 처음으로 돌아갑니다."); continue
//}
//else{
//    try{ retry = funcTop.toInt() }
//    catch(e: NumberFormatException){
//        println("입력이 잘못되었습니다. 처음으로 돌아갑니다."); continue
//    }
//}