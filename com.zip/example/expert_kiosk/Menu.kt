package com.example.expert_kiosk

// 메뉴판 內 메뉴항목 전시를 위한 데이터 클래스(Menu)
// 상속 및 참조 간 제한이 없는 데이터 클래스 사용
data class Menu(val mnNumber:Int, val mnName:String, val mnPrice:Int)